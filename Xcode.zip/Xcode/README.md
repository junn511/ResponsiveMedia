# MEMEAcademic For MacOS
Unofficial J!NS MEME Academic Pack SDK for macOS. Implementations of sending event codes including data encryption/decryption are based on [an official SDK for Android](https://github.com/jins-meme/academic-pack-sdk-for-android/tree/master/JiNS_MEME-academic).

## Instalation
Requires Swift 3/Xcode 8.x

Use Carthage

```
git "git@github.com:shoya140/MEMEAcademic.git"
```

## Usage

```
import Cocoa
import MEMEAcademic

class ViewController: NSViewController, MEMEAcademicDeviceManagerDelegate, MEMEAcademicDeviceDelegate {

    var deviceManager: MEMEAcademicDeviceManager!
    var device: MEMEAcademicDevice!

    override func viewDidLoad() {
        super.viewDidLoad()

        deviceManager = MEMEAcademicDeviceManager.sharedInstance
        deviceManager.delegate = self
        deviceManager.startScanningDevices()
    }

    // MARK: - MEMEAcademicDeviceManagerDelegate

    func memeDeviceFound(_ device: MEMEAcademicDevice!, withDeviceAddress address: String!) {
        deviceManager.stopScanningDevices()
        deviceManager.connectToDevice(device)
    }

    func memeDeviceConnected(_ device: MEMEAcademicDevice!) {
        self.device = device
        self.device.delegate = self

        // Set data mode (mode: [Full, Standard, Quaternion], frequency: [100Hz, 50Hz])
        self.device.setMode(MEMEAcademicModeFull, frequency: MEMEAcademicFrequency100Hz)

        // Set data range (acc: [2g, 4g, 8g, 16g], gyro: [250dps, 500dps, 1000dps, 2000dps])
        self.device.setDataRange(MEMEAcademicRangeAcc2g, gyro: MEMEAcademicRangeGyro250dps)

        self.device.startDataReporting()
    }

    // MARK: - MEMEAcademicDeviceDelegate

    func memeFullDataReceived(_ device: MEMEAcademicDevice!, data: MEMEAcademicFullData!) {
        ...
    }

}
```

## API Reference

### MEMEAcademicDeviceManager

```
func startScanningDevices()
func stopScanningDevices()
func connectToDevice(_ device: MEMEAcademicDevice)
func disconnectDevice(_ device: MEMEAcademicDevice)

// MEMEAcademicDeviceManagerDelegate
func memeDeviceFound(_ device: MEMEAcademicDevice!, withDeviceAddress address: String!)
func memeDeviceConnected(_ device: MEMEAcademicDevice!)
func memeDeviceDisconnected(_ device: MEMEAcademicDevice!)
```

### MEMEAcademicDevice

```
func setMode(_ mode: UInt8, frequency: UInt8)
func setDataRange(_ acc: UInt8, gyro: UInt8)
func startDataReporting()
func stopDataReporting()

// MEMEAcademicDeviceDelegate
func memeStandardDataReceived(_ device: MEMEAcademicDevice!, data: MEMEAcademicStandardData!)
func memeFullDataReceived(_ device: MEMEAcademicDevice!, data: MEMEAcademicFullData!)
func memeQuaternionReceived(_ device: MEMEAcademicDevice!, data: MEMEAcademicQuaternionData!)
```

### MEMEStandardData

```
count: Int
level: Int
accX: Double
accY: Double
accZ: Double
vv1: Double
vh1: Double
vv2: Double
vh2: Double
rawAccX: Int
rawAccY: Int
rawAccZ: Int
rawLeft1: Int
rawRight1: Int
rawLeft2: Int
rawRight2: Int
```

### MEMEFullData

```
count: Int
level: Int
accX: Double
accY: Double
accZ: Double
roll: Double
pitch: Double
yaw: Double
vv: Double
vh: Double
rawAccX: Int
rawAccY: Int
rawAccZ: Int
rawRoll: Int
rawYaw: Int
rawPitch: Int
rawLeft: Int
rawRight: Int
```

### MEMEQuaternionData

Work in Progress...

## License

The MIT License (MIT)

Copyright (c) 2016 Shoya Ishimaru

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.