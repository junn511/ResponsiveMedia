//
//  OrbitViewController.swift
//  MEMEAcademic
//
//  Created by junichi shimizu on 2016/09/24.
//  Copyright © 2016 Shoya Ishimaru. All rights reserved.
//

import Cocoa
import MEMEAcademic
import Foundation
import Darwin.C


class OrbitViewController: NSViewController ,MEMEAcademicDeviceManagerDelegate,MEMEAcademicDeviceDelegate{

    var deviceManager: MEMEAcademicDeviceManager!
    var device: MEMEAcademicDevice!
    
    var Vv = [Double]()
    var diffs = [Double]()
    var diffs_mean: Double = 0.0
    
//    let client:TCPClient = TCPClient(addr:"127.0.0.1",port:8080)
    let client:UDPClient = UDPClient(addr:"127.0.0.1",port:12562)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        deviceManager = MEMEAcademicDeviceManager.sharedInstance
        deviceManager.delegate = self
        deviceManager.startScanningDevices()

// add when set the tcp
//        _ = client.connect(timeout: 1)
        
    }
    
    override func viewWillAppear() {
        view.wantsLayer = true
        view.layer?.backgroundColor = NSColor(red: 0, green: 0, blue: 1, alpha: 1).cgColor
    }
    

    // MARK: - MEMEAcademicDeviceManagerDelegate
    func memeDeviceFound(_ device: MEMEAcademicDevice!, withDeviceAddress address: String!) {
        deviceManager.stopScanningDevices()
        deviceManager.connectToDevice(device)
    }
    
    func memeDeviceConnected(_ device: MEMEAcademicDevice!) {
        self.device = device
        self.device.delegate = self
        self.device.setMode(MEMEAcademicModeFull, frequency: MEMEAcademicFrequency50Hz)
        self.device.setDataRange(MEMEAcademicRangeAcc2g, gyro: MEMEAcademicRangeGyro250dps)
        self.device.startDataReporting()
    }
    
    // MARK: - MEMEAcademicDeviceDelegate
    func memeFullDataReceived(_ device: MEMEAcademicDevice!, data: MEMEAcademicFullData!) {
//        print(data)
        // physical orbit format
//        let data: String = "|" + String(data.count) + "," + String(data.vv) + "," + String(data.vh) + "|"
       
        // george orbit format UDP
//        let data: String = String(data.rawAccX) + "," + String(data.rawAccY) + "," + String(data.rawAccZ) + "," + String(data.rawRoll) + "," + String(data.rawYaw) + "," + String(data.rawPitch) + "," + String(data.rawLeft) + ","  + String(data.rawRight)
        
        
        // Junichi UDP
        let data: String = String(data.count) + "," + String(data.rawAccX) + "," + String(data.rawAccY) + "," + String(data.rawAccZ) + "," + String(data.rawRoll) + "," + String(data.rawYaw) + "," + String(data.rawPitch) + "," + String(data.rawLeft) + "," + String(data.rawRight)
//
        _ = client.send(str:data)
        
    }
}






