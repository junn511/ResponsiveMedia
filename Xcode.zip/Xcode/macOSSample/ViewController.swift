//
//  ViewController.swift
//  macOSSample
//
//  Created by Shoya Ishimaru on 9/15/16.
//  Copyright © 2016 Shoya Ishimaru. All rights reserved.
//

import Cocoa
import MEMEAcademic

class ViewController: NSViewController, MEMEAcademicDeviceManagerDelegate, MEMEAcademicDeviceDelegate {
    
    var deviceManager: MEMEAcademicDeviceManager!
    var device: MEMEAcademicDevice!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        deviceManager = MEMEAcademicDeviceManager.sharedInstance
        deviceManager.delegate = self
        deviceManager.startScanningDevices()
    }
    
    // MARK: - MEMEAcademicDeviceManagerDelegate
    
    func memeDeviceFound(_ device: MEMEAcademicDevice!, withDeviceAddress address: String!) {
        deviceManager.stopScanningDevices()
        deviceManager.connectToDevice(device)
    }
    
    func memeDeviceConnected(_ device: MEMEAcademicDevice!) {
        self.device = device
        self.device.delegate = self
        self.device.setMode(MEMEAcademicModeFull, frequency: MEMEAcademicFrequency100Hz)
        self.device.setDataRange(MEMEAcademicRangeAcc2g, gyro: MEMEAcademicRangeGyro250dps)
        self.device.startDataReporting()
    }
    
    // MARK: - MEMEAcademicDeviceDelegate
    
    func memeFullDataReceived(_ device: MEMEAcademicDevice!, data: MEMEAcademicFullData!) {
//        print(data)
    }
}








