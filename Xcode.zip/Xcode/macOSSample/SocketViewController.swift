//
//  SocketViewController.swift
//  MEMEAcademic
//
//  Created by junichi shimizu on 2016/10/05.
//  Copyright © 2016 Shoya Ishimaru. All rights reserved.
//

import Cocoa
import MEMEAcademic
import Darwin.C


class SocketViewController: NSViewController , MEMEAcademicDeviceManagerDelegate, MEMEAcademicDeviceDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let client:TCPClient = TCPClient(addr:"127.0.0.1",port:8080)
        _ = client.connect(timeout: 1)
        _ = client.send(str: "hee111")
        
        
//        let (success,errmsg) =client.connect(timeout: 1)
//        
//        if success{
//            let (success,errmsg)=client.send(str:"shimi test" )
//            if success{
//                let data=client.read(1024*10)
//                if let d=data{
//                    if let str=String(bytes: d, encoding: String.Encoding.utf8){
//                        print(str)
//                    }
//                }
//            }else{
//                print(errmsg)
//            }
//        }else{
//            print(errmsg)
//        }

    }
    
    override func viewWillAppear() {
        view.wantsLayer = true
        view.layer?.backgroundColor = NSColor(red: 0, green: 1, blue: 1, alpha: 1).cgColor
    }
}


