//
//  BlinkDetectionViewController.swift
//  MEMEAcademic
//
//  Created by junichi shimizu on 2016/09/25.
//  Copyright © 2016 Shoya Ishimaru. All rights reserved.
//

import Cocoa
import MEMEAcademic
import Foundation

class BlinkDetectionViewController: NSViewController ,MEMEAcademicDeviceManagerDelegate,MEMEAcademicDeviceDelegate{
    
    var deviceManager: MEMEAcademicDeviceManager!
    var device: MEMEAcademicDevice!
    
    var Vv = [Double]()
    var diffs = [Double]()
    var diffs_mean: Double = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        deviceManager = MEMEAcademicDeviceManager.sharedInstance
        deviceManager.delegate = self
        deviceManager.startScanningDevices()
    }
    
    override func viewWillAppear() {
        view.wantsLayer = true
        view.layer?.backgroundColor = NSColor(red: 0, green: 0, blue: 1, alpha: 1).cgColor
    }
    
    // MARK: - MEMEAcademicDeviceManagerDelegate
    
    func memeDeviceFound(_ device: MEMEAcademicDevice!, withDeviceAddress address: String!) {
        deviceManager.stopScanningDevices()
        deviceManager.connectToDevice(device)
    }
    
    func memeDeviceConnected(_ device: MEMEAcademicDevice!) {
        self.device = device
        self.device.delegate = self
        self.device.setMode(MEMEAcademicModeFull, frequency: MEMEAcademicFrequency100Hz)
        self.device.setDataRange(MEMEAcademicRangeAcc2g, gyro: MEMEAcademicRangeGyro250dps)
        self.device.startDataReporting()
    }
    
    // MARK: - MEMEAcademicDeviceDelegate
    func memeFullDataReceived(_ device: MEMEAcademicDevice!, data: MEMEAcademicFullData!) {
        self.Vv.append(data.vv)
        
        if self.Vv.count < 2 {
            return
        }
        if self.Vv.count == 2 {
            self.diffs.append(self.Vv[self.Vv.count - 1] - self.Vv[self.Vv.count - 2])
            self.Vv = []
            if self.diffs.count > 10 {
                self.BlinkDetection()
            }else{
                return
            }
        }
    }
    
    func BlinkDetection(){
        diffs_mean = absCalcMean(numbers: self.diffs)
        if diffs_mean > 100 {
            print("blink")
        }else{
            print("no")
        }
        self.diffs = []
    }
    
    func calcMean(numbers: [Double]) -> Double {
        var sum: Double = 0.0
        for num in numbers{
            sum += num
        }
        return sum / Double(numbers.count)
    }
    
    func absCalcMean(numbers: [Double]) -> Double {
        var sum: Double = 0.0
        for num in numbers{
            sum += abs(num)
        }
        return sum / Double(numbers.count)
    }
}
